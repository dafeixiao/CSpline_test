
Getting started:

$ python ./rolling_ball.py --help

