
Depending on your computer speed it could take several minutes to run all of these
tests.
