
This directory contains some simple tests of 3D-DAOSTORM, sCMOS
and the other programs in this project. You can run the tests
like this:

python run_tests.py

The expected results are in the results.txt file.

Notes:
1. You must execute the tests in this directory.
2. The original locations of the molecules that were used to
   generate these data are in the *_olist.bin files.
