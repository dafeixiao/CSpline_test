
Getting started:

$ python ./rcc_drift_correction.py --help
