
Automatic fiducial registration.

Python Programs:

make_test_data - Create test data for experimenting with micrometry
   parameters.

merge_maps - Merge several map files into a single map file in a form
   that is compatible with storm_analysis/multiplane.

micrometry - Calculate a 'first guess' mapping between two localization
   files.

quads - Helper module for micrometry.

refine_map - Refines the 'first guess' map from micrometry.

