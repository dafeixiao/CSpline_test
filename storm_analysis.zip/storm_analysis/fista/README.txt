
This is used by CSpline/Spliner as one approach for identifying initial peak locations in an image.
