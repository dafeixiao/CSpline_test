
DLLs to make compilation on Windows easier.

This is also where the compiled versions of the C libraries / programs are placed.
