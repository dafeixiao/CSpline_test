
Getting started:

$python ./frc_calc2d.py --help


Results are plotted using matplotlib and also saved in output text file.

Note that this is the un-corrected FRC, so repeated localizations of the same
molecule could artificially increase the apparent resolution.
