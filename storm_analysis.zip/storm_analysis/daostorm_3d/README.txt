
Python Programs:

batch_analysis - Used to analyze an entire directory of movies with the
   same parameters.
   
find_peaks - Configuration function for 3D-DAOSTORM peak finding.

mufit_analysis - Use this to perform peak finding and fitting using 3D-DAOSTORM.

z_calibration - Fit wx/wy versus z curves for use in 3D astigmatism imaging.


